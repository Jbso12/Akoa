﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace WindowsFormsApp8
{
    public partial class Form1 : Form
    {
        private BindingList<Ingredient> ingredients = new BindingList<Ingredient>();
        private int nextId = 1;

        public Form1()
        {
            InitializeComponent();
            ingredientsGridView.DataSource = ingredients;
            ingredientsGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
     
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void addButton_Click(object sender, EventArgs e)
        {
            string name = nameTextBox.Text;
            double quantity = (double)quantityNumeric.Value;
            string unit = unitTextBox.Text;
            if (string.IsNullOrWhiteSpace(name) || quantity <= 0)
            {
                MessageBox.Show("Please enter a valid name and quantity.", "Error");
                return;
            }
            Ingredient newItem = new Ingredient(nextId++, name, quantity, unit);
            ingredients.Add(newItem);
            nameTextBox.Clear();
            unitTextBox.Clear();
            quantityNumeric.Value = 0;
            nameTextBox.Focus();
        }
    }
}
