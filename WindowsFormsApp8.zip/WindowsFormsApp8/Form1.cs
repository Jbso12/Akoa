﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp8
{

    public partial class Form1 : Form
    {
        private MySqlConnection connection;
        private MySqlDataAdapter adapter;
        private DataTable datatable;

        // Unused variables from original code, kept for completeness but not necessary for function
        private BindingList<Ingredient> ingredients = new BindingList<Ingredient>();
        private int nextId = 1;
        private object dataGridView1;

        public Form1()
        {
            InitializeComponent();
            // Removed conflicting initial DataSource setup
            // ingredientsGridView.DataSource = ingredients; 
            ingredientsGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            try
            {
                // FIX: Use simple string connection to bypass MySqlConnectionStringBuilder SslMode error.
                // FIX: Use correct database name 'final_ordering_system'.
                string connectionString =
                    "Server=localhost;" +
                    "UserID=root;" +
                    "Password=findyou123L#;" +
                    "Database=mydb;" + // CORRECTED DB NAME
                    "SslMode=Preferred;"; // CORRECTED SslMode HANDLIN

                connection = new MySqlConnection(connectionString);

                // FIX: Corrected SELECT statement columns to match the 'ingredients' table schema
                adapter = new MySqlDataAdapter("SELECT ingredient_id, ingredient_name, unit FROM ingredients", connection);

                // CRITICAL: This generates the necessary INSERT, UPDATE, and DELETE commands for the adapter.
                new MySqlCommandBuilder(adapter);

                datatable = new DataTable();
                adapter.Fill(datatable);

                // CRITICAL: Set the DataGridView source to the DataTable
                ingredientsGridView.DataSource = datatable;
            }
            catch (MySqlException ex)
            {
                // If you are trying to use 'final_ordering_system', change the Database name above.
                MessageBox.Show("Error connecting to database: " + ex.Message);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e) { }
        private void button2_Click(object sender, EventArgs e) { }
        private void numericUpDown1_ValueChanged(object sender, EventArgs e) { }
        private void Form1_Load(object sender, EventArgs e) { }

        private void addButton_Click(object sender, EventArgs e)
        {
            {
                string name = nameTextBox.Text;
                double quantity = (double)quantityNumeric.Value;
                string unit = unitTextBox.Text;

                if (string.IsNullOrWhiteSpace(name) || quantity <= 0)
                {
                    MessageBox.Show("Please enter a valid name and quantity.", "Error");
                    return;
                }

                try
                {
                    // --- PART 1: Insert the New Ingredient Name/Unit into 'ingredients' table ---
                    DataRow newRow = datatable.NewRow();
                    newRow["ingredient_name"] = name;
                    newRow["unit"] = unit;
                    datatable.Rows.Add(newRow);

                    // Push the new ingredient to the database. The database will assign ingredient_id.
                    adapter.Update(datatable);

                    // This updates the DataTable with the new auto-incremented ID from the database.
                    datatable.AcceptChanges();

                    // Retrieve the new ID for use in the next step.
                    long newIngredientId = Convert.ToInt64(newRow["ingredient_id"]);

                    // --- PART 2: Insert the Initial Stock (Quantity) into 'ingredient_stock' table ---

                    // We use a direct command for the secondary table as the DataAdapter only handles 'ingredients'.
                    using (MySqlCommand stockCommand = new MySqlCommand(
                        "INSERT INTO ingredient_stock (ingredient_id, current_stock, expiry_date) VALUES (@id, @stock, @expiry)", connection))
                    {
                        stockCommand.Parameters.AddWithValue("@id", newIngredientId);
                        stockCommand.Parameters.AddWithValue("@stock", quantity);
                        // Using a placeholder expiry date (10 years from now). 
                        // You should eventually add a date control for this.
                        stockCommand.Parameters.AddWithValue("@expiry", DateTime.Now.AddYears(10).ToString("yyyy-MM-dd"));

                        connection.Open();
                        stockCommand.ExecuteNonQuery();
                        connection.Close();
                    }

                    // Clear input fields
                    nameTextBox.Clear();
                    unitTextBox.Clear();
                    quantityNumeric.Value = 0;
                    nameTextBox.Focus();
                }
                catch (MySqlException ex)
                {
                    // If insertion fails, discard the newly added row from the datatable
                    datatable.RejectChanges();
                    MessageBox.Show("Error saving data to database: " + ex.Message);
                }
            }
        }
    }
}

